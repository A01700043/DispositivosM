package com.example.drf47kl.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    private TextView tv;
    String st;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        st=getIntent().getExtras().getString("Value");
        tv=(TextView)findViewById(R.id.hello);
        tv.setText(st);


    }
}
