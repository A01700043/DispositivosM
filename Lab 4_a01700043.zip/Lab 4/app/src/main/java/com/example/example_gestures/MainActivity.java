package com.example.example_gestures;

import android.content.Intent;
import android.app.Activity;
import android.os.Bundle;
import android.support.v4.view.GestureDetectorCompat;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.Toast;

public class MainActivity extends Activity implements
        GestureDetector.OnGestureListener,
        GestureDetector.OnDoubleTapListener{

    private static final int SWIPE_THRESHOLD = 100;
    private static final int SWIPE_VELOCITY_THRESHOLD = 100;

    private GestureDetectorCompat GDC;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GDC = new GestureDetectorCompat(this,this);
        GDC.setOnDoubleTapListener(this);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event){
        if (this.GDC.onTouchEvent(event)) {
            return true;
        }
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onDown(MotionEvent event) {
        //Toast toast = Toast.makeText(getApplicationContext(), "OnDown", Toast.LENGTH_SHORT); toast.show();
        return true;
    }

    @Override
    public void onLongPress(MotionEvent event) {
        Toast toast = Toast.makeText(getApplicationContext(), "OnLongPress" , Toast.LENGTH_SHORT); toast.show();
    }

    @Override
    public boolean onSingleTapUp(MotionEvent event) {
        Toast toast = Toast.makeText(getApplicationContext(), "onSingleTapUp" , Toast.LENGTH_SHORT); toast.show();
        return true;
    }

    @Override
    public boolean onDoubleTap(MotionEvent event) {
        Toast toast = Toast.makeText(getApplicationContext(), "onDoubleTap" , Toast.LENGTH_SHORT); toast.show();
        return true;
    }

    @Override
    public boolean onFling(MotionEvent pp, MotionEvent pr, float vx, float vy) {

        boolean result = false;
        try {
            float diffY = pr.getY() - pp.getY();
            float diffX = pr.getX() - pp.getX();
            if (Math.abs(diffX) > Math.abs(diffY)) {
                if (Math.abs(diffX) > SWIPE_THRESHOLD && Math.abs(vx) > SWIPE_VELOCITY_THRESHOLD) {
                    if (diffX > 0) {
                        Toast.makeText(getApplicationContext(), "Desliza Derecha." , Toast.LENGTH_SHORT).show();
                        Intent myIntent = new Intent(MainActivity.this, RightActivity.class);
                        startActivity(myIntent);
                    } else {
                        Toast.makeText(getApplicationContext(), "Desliza Izquierda." , Toast.LENGTH_SHORT).show();
                        Intent myIntent = new Intent(MainActivity.this, LeftActivity.class);
                        startActivity(myIntent);
                    }
                    result = true;
                }
            }
            else if (Math.abs(diffY) > SWIPE_THRESHOLD && Math.abs(vy) > SWIPE_VELOCITY_THRESHOLD) {
                if (diffY > 0) {
                    Toast.makeText(getApplicationContext(), "Desliza Abajo." , Toast.LENGTH_SHORT).show();
                    Intent myIntent = new Intent(MainActivity.this, DownActivity.class);
                    startActivity(myIntent);
                } else {
                    Toast.makeText(getApplicationContext(), "Desliza Arriba." , Toast.LENGTH_SHORT).show();
                    Intent myIntent = new Intent(MainActivity.this, UpActivity.class);
                    startActivity(myIntent);
                }
                result = true;
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }

        return result;

    }

    //Redundant Events

    @Override
    public boolean onDoubleTapEvent(MotionEvent event) {
        //Toast toast = Toast.makeText(getApplicationContext(), "onDoubleTapEvent" + event.toString(), Toast.LENGTH_SHORT); toast.show();
        return true;
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent event) {
        //Toast toast = Toast.makeText(getApplicationContext(), "onSingleTapConfirmed" + event.toString(), Toast.LENGTH_SHORT); toast.show();
        return true;
    }

    @Override
    public void onShowPress(MotionEvent event) {
        //Toast toast = Toast.makeText(getApplicationContext(), "OnShowPress" + event.toString(), Toast.LENGTH_SHORT); toast.show();
    }

    @Override
    public boolean onScroll(MotionEvent event1, MotionEvent event2, float distanceX,
                            float distanceY) {
        //Toast toast = Toast.makeText(getApplicationContext(), "onScroll" + event1.toString() + "; " + event2.toString(), Toast.LENGTH_SHORT); toast.show();
        return true;
    }
}